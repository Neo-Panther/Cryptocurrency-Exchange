# Cryptocurrency Exchange
This project aims to build a cryptocurrency exchange prototype with a feature to request cryptocurrency in addition to sending it. This feature is implemented with HMAC verification. Consensus mechanism used is Proof of Work (PoW). A menu driven program serves as the frontend.

## How to run the project
To run the project, run the `main.py` file in a terminal using python 3. Pick the options in the menu as shown.

## List of Team Members

- Aryan Gupta     `2021A7PS0162H`
- Rohan Chavan    `2021A7PS2739H`
- Mihir Kulkarni  `2021A7PS2689H`
- Subal Tankwal   `2021A7PS1407H`
- Kshitiz Agarwal	`2021A7PS1818H`